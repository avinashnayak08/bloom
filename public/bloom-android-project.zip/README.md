# Bloom App – Android Studio & AdMob Integration

## Overview
**Bloom** is a women's wellness application tailored for PCOS health management, daily goal tracking, symptom correlation, and Google AdMob monetization.

## Architecture
- **Language**: Kotlin 1.9+
- **UI Framework**: Jetpack Compose with Material3
- **Design System**: Warm terracotta (\